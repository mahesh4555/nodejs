
const mongoose = require('mongoose')

const AlienSchema = mongoose.Schema({
    book_id : Number,
    name: String,
    price: Number,
    quantity: Number
  });

  // compile schema to model
//   var Book = mongoose.model('Book', AlienSchema, 'bookstore2');

  // a document instance


  module.exports = mongoose.model('Magza',AlienSchema,'magazine')
// Alien1 = mongoose.model('Alien',AlienSchema,'bookss')
// module.exports = Alien1
const mongoose = require('mongoose');
 
const express = require('express');
const app = express();
// const Alien = require('./models/alien.js')


const fs = require("fs");

app.use(express.json());
url = 'mongodb://localhost:27017/bookstamp'
// make a connection
mongoose.connect(url, {useNewUrlParser: true,  useUnifiedTopology: true, useFindAndModify: false });
 
// get reference to database
var db = mongoose.connection;
 
db.on('error', console.error.bind(console, 'connection error:'));
 
db.once('open', function() {
    console.log("Connection Successful!");
    
})


const alienRouter = require('./routes/alien')
app.use('/alien', alienRouter)


const magazineRouter = require('./routes/magazine')
app.use('/magazine', magazineRouter)


var server = app.listen(8011, function () {
   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)
})
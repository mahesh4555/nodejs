const express = require('express');
const router = express.Router();

const Magza = require('../models/magazine')


// This responds with "Hello World" on the homepage
router.get('/get_all_books', async function (req, res) {
    console.log("Got a GET request for the homepage");
  //  res.send('Hello GET');

    try{
      const alien_val = await Magza.find()
      res.json(alien_val)
    } catch(err){
      res.send("Error")
    }
   
})


router.get('/get_book/:book_id', async function (req, res) {
  console.log("Got a GET request for the homepage");
//  res.send('Hello GET');
//   const alien_val = await Alien.find()
//   console.log(alien_val)

  try{
//    var alien = await Alien.find()
    // var alien = await Alien.findById(req.params.book_id)
    console.log("quantity:"+req.params.book_id)
    const filter = { book_id: req.params.book_id };
    var alien = await Magza.find(filter)
    res.json(alien)
  } catch(err){
    res.send("Error")
  }
 
})




router.post('/save_new_book', async function (req, res) {
    console.log("Got a POST request for the homepage");
  //sample_data_to_send : { name: 'new stamp 1', price: 20, quantity: 12 }

   // console.log(req.body.name);
    // var data = new Alien( {
    //   name : req.body.name,
    //   price = req.body.price,
    //  quantity = req.body.quantity
    // })

    var book = new Magza({ book_id: req.body.book_id, name: req.body.name, price: req.body.price, quantity: req.body.quantity });

    try{
      var alien_val = await book.save()
      res.json(alien_val)
    } catch(err){
      res.send("Error")
    }
   

    // res.send(req.body.name);
     // const alien_val = Alien.findOne()
     // console.log(alien_val)
    //  var book1 = new Alien({ name: 'new stamp 1', price: 20, quantity: 12 });
  
     // save model to database
    //  book1.save(function (err, book) {
    //    if (err) return console.error(err);
    //    console.log(book.name + " saved to bookstore collection.");
    //  });
    
 })


 
router.patch('/patch_book/:book_id', async function (req, res) {
  console.log("Got a PATCH request for the homepage");
  //sample_data - {"price":34} 

  try{
//    var alien = await Alien.find()
    // var alien = await Alien.findById(req.params.book_id)
    console.log("quantity:"+req.params.book_id)
    const filter = { book_id: req.params.book_id };
    var alien = await Magza.findOne(filter)
    alien.price =  req.body.price
    const al = await alien.save()
    res.json(alien)
  } catch(err){
    res.send("Error")
  }
 
})


 
router.put('/update_book/:book_id', async function (req, res) {
  console.log("Got a PUT request for the homepage");

    

    try{
      const filter =  req.params.book_id ;// { book_id:0 };
    const update = req.body; // { name: 'new stamp 1', price: 20, quantity: 12 }
      var alien_val = await Magza.findOneAndUpdate(filter,update)
      res.json(alien_val)
    } catch(err){
      res.send("Error")
    }

    
  });


  router.delete('/delete_book/:book_id', async function (req, res) {
    console.log("Got a DELETE request for the homepage");
  
      
  
      try{
        const filter =  { book_id:req.params.book_id }   ;// { book_id:0 };
    //  const update = req.body; // { name: 'new stamp 1', price: 20, quantity: 12 }
        var alien_val = await Magza.findOneAndDelete(filter)
        res.json(alien_val)
      } catch(err){
        res.send("Error")
      }
  
      
    });



module.exports = router